clear
../xkas test.bin test.asm
